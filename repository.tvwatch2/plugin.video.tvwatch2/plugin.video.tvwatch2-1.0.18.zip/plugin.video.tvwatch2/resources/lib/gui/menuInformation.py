import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.tvwatch2/?site=cGui&function=viewInfo)", True)
